package com.bean;

public class Voter_bean {
		int Voter_Number;

		public int getVoter_Number() {
			return Voter_Number;
		}

		public void setVoter_Number(int voter_Number) {
			Voter_Number = voter_Number;
		}	
}
