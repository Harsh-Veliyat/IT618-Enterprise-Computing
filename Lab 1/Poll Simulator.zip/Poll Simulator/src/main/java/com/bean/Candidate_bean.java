package com.bean;

public class Candidate_bean {
		String Candidate_name;
		int vote=0;

		public int getVote() {
			return vote;
		}

		public void setVote(int vote) {
			this.vote = vote;
		}

		public String getCandidate_name() {
			return Candidate_name;
		}

		public void setCandidate_name(String candidate_name) {
			Candidate_name = candidate_name;
		}
		
}
